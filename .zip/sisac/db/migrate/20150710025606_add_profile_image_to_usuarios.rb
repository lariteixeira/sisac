class AddProfileImageToUsuarios < ActiveRecord::Migration
  def change
    add_column :usuarios, :profile_image_id, :string
  end
end
